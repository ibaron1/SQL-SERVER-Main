select name, is_parameterization_forced 
from sys.databases
--where name=''