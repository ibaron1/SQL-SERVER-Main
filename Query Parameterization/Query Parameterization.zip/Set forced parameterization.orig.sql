alter database FALCON_SRF_RATES set parameterization forced with no_wait

go

--alter database FALCON_SRF_RATES set parameterization simple with no_wait