select id, Name, parentCpartyId, principal, pseudoLegal, trSdsId,percentOwned,* 
from FALCON_SRF_CacheQA.srf_cache.D_SDSRefData 
where id='41226858'

select id, Name, parentCpartyId, principal, pseudoLegal, trSdsId,percentOwned,* 
from FALCON_SRF_CacheQA.srf_cache.D_SDSRefData 
where id='41226841'

select * from FALCON_SRF_Credit_QA.srf_main.counterParty where Id='41226858'

select * from FALCON_SRF_CacheQA.srf_main.counterParty2

--1.
select id, Name, parentCpartyId, principal, pseudoLegal, trSdsId,* from srf_cache.D_SDSRefData where id='40021228' 
select id, Name, parentCpartyId, principal, pseudoLegal, trSdsId,* from srf_cache.D_SDSRefData where id='10309247'
select * from FALCON_SRF_CacheQA.srf_main.counterParty2
--2. 
select id, Name, parentCpartyId, principal, pseudoLegal, trSdsId,* from srf_cache.D_SDSRefData where id='10007112'
select * from FALCON_SRF_CacheQA.srf_main.counterParty2 
--3.
select id, Name, parentCpartyId, principal, pseudoLegal, trSdsId,* from srf_cache.D_SDSRefData where id='10008228'
select id, Name, parentCpartyId, principal, pseudoLegal, trSdsId,* from srf_cache.D_SDSRefData where id='40043535' --taking values from trSdsId
select * from FALCON_SRF_CacheQA.srf_main.counterParty2 
 --4.
select id, Name, parentCpartyId, principal, pseudoLegal, trSdsId,* from srf_cache.D_SDSRefData where id='10009291' 
select id, Name, parentCpartyId, principal, pseudoLegal, trSdsId,* from srf_cache.D_SDSRefData where id='10001649'
select * from FALCON_SRF_CacheQA.srf_main.counterParty2 