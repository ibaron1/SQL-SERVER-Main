sp_spaceused @UPDATEUSAGE='TRUE'

-- more accurate
dbcc showfilestats 