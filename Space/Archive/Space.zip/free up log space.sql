use riskworld -- riskworld logger70
go

dbcc shrinkfile(2, TRUNCATEONLY )