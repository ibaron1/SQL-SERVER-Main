DBCC SQLPERF(logspace)

DBCC LOGINFO

DBCC OPENTRAN

backup log riskworld with no_log

http://www.mssqltips.com/tip.asp?tip=1225