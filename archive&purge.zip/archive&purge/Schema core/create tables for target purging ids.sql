use TFM_Archive
go

create table core.transactionIdPurging(transactionId int constraint PK_transactionId1 primary key)
create table core.activityIdPurging(activityId int constraint PK_activityId1 primary key)

go