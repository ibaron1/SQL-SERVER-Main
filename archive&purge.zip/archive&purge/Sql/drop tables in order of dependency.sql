if object_id('tfmarchive.RequestKeyAttributes') is not null
  drop table tfmarchive.RequestKeyAttributes;

if object_id('tfmarchive.Payload') is not null
  drop table tfmarchive.Payload;

if object_id('tfmarchive.Activity') is not null
  drop table tfmarchive.Activity;

if object_id('tfmarchive.Step') is not null
  drop table tfmarchive.Step;

if object_id('tfmarchive.Request') is not null
  drop table tfmarchive.Request;

  